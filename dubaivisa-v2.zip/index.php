<?php
    include('includes/header.php');
?>

<div class="container-fluid mt-0" id="main-page">
    <div class="row justify-content-center">
        <div class="col-12 col-md-12 pl-0 pr-0">
                <video
                        id="my-video"
                        class="video-js"
                        preload="auto"
                        width="auto"
                        autoplay
                        loop
                        height="auto"
                        played
                        data-setup="{}"
                        loop
                        muted
                    >
                    <source src="assets/videos/slider-video.mp4" type="video/mp4" />
                    <source src="assets/videos/slider-video.mp4" type="video/webm" />
                    <p class="vjs-no-js">
                    To view this video please enable JavaScript, and consider upgrading to a
                    web browser that
                    </p>
                </video>          
        </div>
    </div>
</div>

<div class="container mt-0" id="main-page">
    <div class="row justify-content-center">
        <div class="col-12 col-md-12 mt-4">
            <div class="row justify-content-center">
                <div class="col-4 col-md-3">
                    <img src="assets/images/online-Web-tag-Edit.jpg" class="img-fluid hvr-grow cursor-pointer"/>
                </div>
                <div class="col-4 col-md-3">
                    <img src="assets/images/Credit-card-offers.jpg" class="img-fluid hvr-grow cursor-pointer"/>
                </div>
            </div>
        </div>
        <div class="col-12 col-md-12 mt-4 mb-4">
            <div class="home-demo partners-list">
                <div class="row">
                    <div class="large-12 columns">                  
                        <div class="owl-carousel owl-theme">
                            <div class="item">
                                <img src="assets/images/partners/damrologo.png" alt="" class="img-fluid"/>
                            </div>
                            <div class="item">
                                <img src="assets/images/partners/panasoniclogo.png" alt="" class="img-fluid"/>
                            </div>
                            <div class="item">
                                <img src="assets/images/partners/samsunglogo.png" alt="" class="img-fluid"/>
                            </div>
                            <div class="item">
                                <img src="assets/images/partners/hisenselogo.png" alt="" class="img-fluid"/>   
                            </div>
                            <div class="item">
                                <img src="assets/images/partners/preethilogo.png" alt="" class="img-fluid"/> 
                            </div>
                            <div class="item">
                                <img src="assets/images/partners/jacklogo.png" alt="" class="img-fluid"/>
                            </div>
                            <div class="item">
                                <img src="assets/images/partners/innovex-logo-min.png" alt="" class="img-fluid"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
        </div>
    </div>
</div>
<?php
    include('includes/footer.php');
?>   